#
#   _   _   ___  _____  _   _____________ _____ _   _ _____  ___   _   _ 
#  | | | | / _ \/  __ \| | / /_   _| ___ \  _  | \ | |_   _|/ _ \ | \ | |
#  | |_| |/ /_\ \ /  \/| |/ /  | | | |_/ / | | |  \| | | | / /_\ \|  \| |
#  |  _  ||  _  | |    |    \  | | |    /| | | | . ` | | | |  _  || . ` |
#  | | | || | | | \__/\| |\  \ | | | |\ \\ \_/ / |\  |_| |_| | | || |\  |
#  \_| |_/\_| |_/\____/\_| \_/ \_/ \_| \_|\___/\_| \_/\___/\_| |_/\_| \_/
#
#                   ~ Tools For Hacking by Mr. SAGE ~

clear

sudo chmod +x /etc/

clear

sudo chmod +x /usr/share/doc

clear

sudo rm -rf /usr/share/doc/hacktronian/

clear

cd /etc/

clear

sudo rm -rf /etc/thehackingsage

clear

mkdir thehackingsage

clear

cd thehackingsage

clear

git clone https://github.com/thehackingsage/hacktronian.git

clear

cd hacktronian

clear

sudo chmod +x install.sh

clear

./install.sh

clear
