<p align="center"><img src="https://github.com/thehackingsage/hacktonian/blob/master/logo.png?raw=true" /></p>

<p align="center">***Pentesing Tools That All Hacker Needs.***</p>

## HACKTRONIAN Menu :

- Information Gathering
- Password Attacks
- Wireless Testing
- Exploitation Tools
- Sniffing & Spoofing
- Web Hacking
- Private Web Hacking
- Post Exploitation
- Install The HACKTRONIAN

### Information Gathering:

- Nmap
- Setoolkit
- Port Scanning
- Host To IP
- wordpress user
- CMS scanner
- XSStrike
- Dork - Google Dorks Passive Vulnerability Auditor
- Scan A server's Users
- Crips

### Password Attacks:

- Cupp
- Ncrack

### Wireless Testing:

- reaver
- pixiewps
- Fluxion

### Exploitation Tools:

- ATSCAN
- sqlmap
- Shellnoob
- commix
- FTP Auto Bypass
- jboss-autopwn

### Sniffing & Spoofing:

- Setoolkit
- SSLtrip
- pyPISHER
- SMTP Mailer

### Web Hacking:

- Drupal Hacking
- Inurlbr
- Wordpress & Joomla Scanner
- Gravity Form Scanner
- File Upload Checker
- Wordpress Exploit Scanner
- Wordpress Plugins Scanner
- Shell and Directory Finder
- Joomla! 1.5 - 3.4.5 remote code execution
- Vbulletin 5.X remote code execution
- BruteX - Automatically brute force all services running on a target
- Arachni - Web Application Security Scanner Framework

### Private Web Hacking:

- Get all websites
- Get joomla websites
- Get wordpress websites
- Control Panel Finder
- Zip Files Finder
- Upload File Finder
- Get server users
- SQli Scanner
- Ports Scan (range of ports)
- ports Scan (common ports)
- Get server Info
- Bypass Cloudflare

### Post Exploitation:

- Shell Checker
- POET
- Weeman

## Installation in Linux :

This Tool Must Run As ROOT !!!

```git clone https://github.com/thehackingsage/hacktronian.git```

```cd hacktronian```

```chmod +x install.sh```

```./install.sh```

That's it.. you can execute tool by typing **hacktronian**

## Installation in Android :

Open [Termux](https://play.google.com/store/apps/details?id=com.termux)

```pkg install git```

```pkg install python```

```git clone https://github.com/thehackingsage/hacktronian.git```

```cd hacktronian```

```chmod +x hacktronian.py```

```python2 hacktronian.py```

## Video Tutorial : 

YouTube : https://www.youtube.com/watch?v=1LJlyQAQby4

## License :

[MIT Licence](https://github.com/thehackingsage/hacktronian/blob/master/LICENSE)

That's It... If You Like This Repo. Please Share This With Your Friends..

& Don't Forget To Follow Me At [Twitter](https://www.twitter.com/thehackingsage), [Instagram](https://www.instagram.com/thehackingsage), [Github](https://www.github.com/thehackingsage) & SUBSCRIBE My [YouTube](https://www.youtube.com/channel/UCYK1n9A4TUq1CvGc6F3DzoA) Channel..!!!

***Thankyou.***
***Keep Visiting..***
***Enjoy.!!! :)***
