# Termux-Os
All in One Termux Os..!! (New)

[![Termux-_Os.png](https://s26.postimg.org/v3m2sqg1l/Termux-_Os.png)](https://postimg.org/image/pffs1ubp1/)

# Installation...

1) git clone https://github.com/Bhai4You/Termux-Os

2) cd Termux-Os

3) chmod +x requirement.sh Termux-Os.sh

4) bash requirement.sh

5) bash Termux-Os.sh

[*] Enjoy Hacking....


These are <b style='color:black'>red words</b>.

<body style="background-color:black;">
</body>
